// Inclusion de la STL
#include<iostream>
using namespace std;

int main(){
    return 0;
}
